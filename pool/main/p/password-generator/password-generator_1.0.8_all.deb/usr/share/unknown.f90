! Hello.f90
! char(9) -> tab
! char(10) -> \n (newline)
! char(27) -> ANSI Escape
! Use char():
! char()//...//
program hello
  implicit none
  print *, char(27)//"[1;32mgenpasswd 1.0.8 - Generate strong passwords and logs generating actions"//char(27)//"[0m"
  !print *, ""//char(10)
  print *, char(27)//"[0;32mUpdates in new version: "//char(27)//"[0m"
  print *, ""//char(10)
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- GPLv3 LICENSE invented;"//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- Working in progress options can be used now in genpasswdtui;"//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- No needs to use figlet and boxes as dependencies;"//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- Invented news for checking updates;"//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- No mouse mode in genpasswdtui is released now."//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- Updated genpasswdtui manpages."//char(27)//"[0m"
  print *, char(9)//char(27)//"[1;38;2;255;165;0m- Invented genpasswd-modern-tui with more modern TUI interface for newbies."//char(27)//"[0m"
  print *, ""//char(10)
  print *, char(27)//"[1;37mSee our manpage using 'man genpasswdtui' if you need more help."//char(27)//"[0m"
  print *, char(27)//"[1;37mMore ways to install password-generator, please visit https://github.com/Who5673/genpasswd/releases"//char(27)//"[0m"
end program hello
