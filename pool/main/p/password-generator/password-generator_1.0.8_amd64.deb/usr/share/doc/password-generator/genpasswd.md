% genpasswd(1) | genpasswd
% 1.0.8 | who5673 | June 2025

# NAME
__genpasswd__ - Generate strong passwords and logs generating actions via Command Line Interface.  

# SYNOPSIS  
  
**genpasswd** # Pkexec supported, but no options can be specified 
  
or  
    
__/usr/lib/password-generate/genpasswd [OPTIONS]__  

# DESCRIPTION
**genpasswd**  is  an app that generates a passphrase for you to use it Also, it logs every passphrases that you have used before. It has 2 environment to run:  
genpasswd for the Command Line Interface (CLI) and genpasswdtui for Text-based User Interface (TUI). Genpasswdtui is being worked in process, so some options may
not  be  executed  like  you  want  to.  Genpasswd  (CLI)  is  not only a Python script for generating passwords in command-line interface and appending logs in
**/var/log/secrof.log**, but it also a Python library for checking password outputs and generate them in python3.  
  
(**NOTE**: genpasswdtui used ncurses.h and some C libraries to build, not python! genpasswdtui needs to be run as __root__ or ___sudo___!)  
  
In here, this manpage will help you how to use genpasswd.  
