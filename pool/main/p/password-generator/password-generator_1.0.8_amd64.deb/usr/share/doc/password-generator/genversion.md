% genversion(1) | genversion
% 1.0.8 | who5673 | June 2025

# NAME
genversion - Prints password-generator package version

# SYNOPSIS
__genversion__

# DESCRIPTION
  
genversion is a command that prints the version of password-generator package. Unlike __genpasswd__, __genpasswdtui__ (with parameter --version), this command  
prints only the version as an output, never include other strings like them.  

# SEE ALSO
genpasswd(1), genpasswdtui(1), genpasswdnews(1)

Copyright (c) by who5673 June 2025. All rights served with GPLv3 License.
