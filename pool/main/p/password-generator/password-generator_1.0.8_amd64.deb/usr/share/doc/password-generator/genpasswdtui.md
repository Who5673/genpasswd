% genpasswdtui(1) | genpasswdtui
% who5673 | June 2025 | version 1.0.8

# NAME
genpasswdtui - Generate strong passwords and logs generating actions via Text-based User Interface.  

# SYNOPSIS  
  
**genpasswdtui** # Pkexec supported, but no options can be specified 
  
or  
    
__/usr/lib/password-generate/genpasswdtui [OPTIONS]__  

# DESCRIPTION
**genpasswd**  is  an app that generates a passphrase for you to use it Also, it logs every passphrases that you have used before. It has 2 environment to run:  
genpasswd for the Command Line Interface (CLI) and genpasswdtui for Text-based User Interface (TUI). Genpasswdtui is being worked in process, so some options may
not  be  executed  like  you  want  to.  Genpasswd  (CLI)  is  not only a Python script for generating passwords in command-line interface and appending logs in
**/var/log/secrof.log**, but it also a Python library for checking password outputs and generate them in python3.  
  
(**NOTE**: genpasswdtui used ncurses.h and some C libraries to build, not python! genpasswdtui needs to be run as __root__ or ___sudo___!)  
  
In here, this manpage will help you how to use genpasswdtui.  
  
**Keyboard and mouse**  
  
Genpasswdtui has two modes: mouse mode and no-mouse mode.  
This is how to use the keyboard in genpasswdtui:  
  
- __Arrow up__: Go to the option that is on the current option  
- __Arrow down__: Go to the option that is under the current option  
- __Arrow right__ (or __Enter__): Interact the option  
  
This is how to use the mouse in genpasswdtui (NOTE: no mouse mode needs to be __DISABLED__):  
  
- **BUTTON4-PRESSED** (Scroll up): Go to the option that is on the current option  
- __BUTTON5-PRESSED__ (Scroll down): Go to the option that is under the current option  
- __BUTTON1-CLICKED__ (Click using the left button of the mouse): Interact an option (the cursor does not have to be in the option you wnat to choose, it's 
like the Enter button)  
  
# OPTIONS
genpasswdtui has some arguments to use, you must run "/usr/lib/password-generate/genpasswdtui [OPTIONS]" to deal with (not genpasswdtui directly), as pkexec will control that command to run:  
  
**`--version`**  
  
    Prints the current version of genpasswdtui and exits.
  
**`-h, --help`**  
  
    Prints the short texts to help you deal with genpasswdtui faster with options and exits, has colors.  
  
**get-help**  
  
    Prints more verbose instructions than --help and exits. Has no colors, but it contains a short passage of a LICENSE.  
  
**`-nm --no-mouse no-mouse-mode=1 no-mouse-mode=enabled no-mouse-mode=yes no-mouse-mode=true`**  
  
    Run the app in no-mouse-mode so that only keyboard can deal with the menu in that program. Default mouse mode is yes, and you can open it by skipping this  
    options.  
  
**no-mouse-mode=0 --mouse-mode no-mouse-mode=no no-mouse-mode=false no-mouse-mode=disabled**  
  
    Default mode in genpasswdtui. Run the app in mouse mode so that you can scroll up, scroll down and click to interact the menu options in the app. Pkexec will  
    run this mode if you only run _genpasswdtui_ command with sudo or root user.

# OTHER FILES AND SCRIPTS
genpasswdtui has a lot of configuration files, mostly are in /usr/share and /usr/lib/password-generate. You can use command 'apt download password-generator' and
extract that .deb file to look inside the package.  
GPLv3 License is in /usr/share/doc/password-generator/LICENSE, so __DO NOT__ make a copyright of this app, and use this program __WITHOUT WARRANTY__.

# SEE ALSO
**genpasswd(1), genpasswdtui(1), genpasswdnews(1)**, __genversion(1)__  

(c) 2025 who5673. All rights served. You can edit your config files to fix bugs, but do not publish another copyright of it into social media.
